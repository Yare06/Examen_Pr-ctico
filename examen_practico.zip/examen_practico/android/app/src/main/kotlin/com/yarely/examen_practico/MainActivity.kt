package com.yarely.examen_practico

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
