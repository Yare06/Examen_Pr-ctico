import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Login App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LoginScreen(),
    );
  }
}

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  // Simulamos una lista de usuarios con login y nombre completo
  final List<Map<String, String>> users = [
    {'username': 'Yarely', 'password': '1234', 'fullname': 'Yarely Karime Sandoval Medina'},
    {'username': 'Fernanda', 'password': '5678', 'fullname': 'Fernanda Grisel Lopez Cuevas'}
  ];

  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _attemptsController = TextEditingController();

  int failedAttempts = 0;
  String errorMessage = '';
  String currentFullname = '';  // Para almacenar el nombre completo del usuario

  void _login() {
    String username = _usernameController.text;
    String password = _passwordController.text;

    bool userFound = false;

    for (var user in users) {
      if (user['username'] == username && user['password'] == password) {
        userFound = true;
        currentFullname = user['fullname']!;
        break;
      }
    }

    if (userFound) {
      setState(() {
        errorMessage = '';
        failedAttempts = 0;
      });
      // Navegamos a la pantalla de bienvenida si el login es exitoso
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => WelcomeScreen(
            username: _usernameController.text,
            fullname: currentFullname,
          ),
        ),
      );
    } else {
      setState(() {
        failedAttempts++;
        errorMessage = 'Incorrect username or password';
        _attemptsController.text = failedAttempts.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Inicio de sesión',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(labelText: 'Login'),
            ),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _login,
              child: Text('Entrar'),
            ),
            SizedBox(height: 20),
            Text(
              errorMessage,
              style: TextStyle(color: Colors.red),
            ),
            SizedBox(height: 20),
            TextField(
              controller: _attemptsController,
              readOnly: true,
              decoration: InputDecoration(labelText: 'Intentos fallidos'),
            ),
          ],
        ),
      ),
    );
  }
}

// Pantalla de bienvenida
class WelcomeScreen extends StatelessWidget {
  final String username;  // Login del usuario
  final String fullname;  // Nombre completo del usuario

  WelcomeScreen({required this.username, required this.fullname});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Bienvenido'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(  // Widget Column para organizar los widgets
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Bienvenido a la aplicación',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text(
              'Login: $username',  // Widget Text para el login del usuario
              style: TextStyle(fontSize: 18),
            ),
            Text(
              'Nombre completo: $fullname',  // Widget Text para el nombre completo del usuario
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}
